import tkinter as tk
import threading
import time
import random
import pygame
import sys
import os

from void_terminal import run_terminal

exit_key_combo = {"q"}
pressed_keys = set()

def play_sound():
    pygame.mixer.init()
    pygame.mixer.music.load(os.path.join("resources", "creepy_sound.mp3"))
    pygame.mixer.music.play(-1)  # Loop forever

def check_keys(event):
    pressed_keys.add(event.keysym)
    if exit_key_combo.issubset(pressed_keys):
        pygame.mixer.music.stop()
        root.destroy()

def release_keys(event):
    if event.keysym in pressed_keys:
        pressed_keys.remove(event.keysym)

root = tk.Tk()
root.title("VOID OS")
root.attributes("-fullscreen", True)
root.configure(bg="black")
root.bind("<KeyPress>", check_keys)
root.bind("<KeyRelease>", release_keys)

# Start creepy terminal in a thread
threading.Thread(target=run_terminal, args=(root,), daemon=True).start()

# Start sound in a thread
threading.Thread(target=play_sound, daemon=True).start()

root.mainloop()
