VOID OS - Nightmare Edition
===========================

Features:
- Fullscreen, unescapable terminal window
- Creepy auto-typing
- Looping ambient sound
- Hidden exit combo: q
- Autostart via registry (see autostart.bat)

To build EXE:
1. Install Python 3, Pillow, Pygame
2. Run: pyinstaller --noconsole --onefile --icon=resources/icon.ico void_main.py

Have fun pranking 😈
