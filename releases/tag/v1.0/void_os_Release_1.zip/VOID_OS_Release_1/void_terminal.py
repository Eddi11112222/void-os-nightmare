import tkinter as tk
import time
import random

def creepy_typing(text_widget, lines):
    for line in lines:
        for char in line:
            text_widget.insert("end", char)
            text_widget.see("end")
            text_widget.update()
            time.sleep(0.05)
        text_widget.insert("end", "\n")
        time.sleep(0.5)

def run_terminal(root):
    terminal = tk.Text(root, bg="black", fg="green", font=("Courier", 14))
    terminal.pack(expand=True, fill="both")
    terminal.insert("end", "Booting VOID OS...\n\n")
    terminal.configure(state="disabled")

    def run_typing():
        terminal.configure(state="normal")
        lines = [
            "> Mounting encrypted volume...",
            "> Accessing BIOS...",
            "> IP traced: 192.168." + str(random.randint(0, 255)) + "." + str(random.randint(0, 255)),
            "> Webcam: online",
            "> Uploading data to darknet...",
            "> Injecting backdoor...",
            "> Failed to erase C:\\System32\\ - RETRYING..."
        ]
        creepy_typing(terminal, lines)
        terminal.insert("end", "\nPress nothing. I’m watching.\n")
        terminal.configure(state="disabled")

    run_typing()
